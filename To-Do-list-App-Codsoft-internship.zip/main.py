task = []
def add_task(tasks):
  task = input("Enter the task: ")
  tasks.append(task)
  print(f"Task '{task}' added to the list.")
  
def list_tasks(tasks):
  if not tasks:
    print("there are no tasks currently.")
  else:
    print("current tasks:")
    for index, task in enumerate(tasks, start=1):
        print(f"{index}. {task}")
      
      ### Task #1. Do the home work outside.

      ### Task #2. Go to the laibrary.

      ### Task #3. Go to the gym.

      ### Task #4. Call mom.
def delete_task():
  try:
      task_index = int(input("Enter the index of the task to delete: ")) - 1
      if task_index < 0 or task_index >= len(task):
          print("Invalid task index")
      else:
          task.pop(task_index)
          print("Task deleted")
  except ValueError:
      print("Invalid input")
      
if __name__ == "__main__":
 ### Create a loop to run the app
  print("Welcome to the To Do list app :)")  
while True:
  print("What would you like to do?")
  print("please selecet one of the following options")
  print("1. Add a task")
  print("2. Remove a task")
  print("3. List tasks")
  print("4. Quit")
  choice = input("Enter your choice (1-4): ")
  if(choice == "1"):
    add_task(task)
  elif(choice == "2"):
    delete_task()  
  elif(choice == "3"):
    print("Here is your list of tasks: ")
    print(task)
  elif(choice == "4"):
    print("Goodbye!👋🏻")
    break
  else:
    print("Invalid choice. Please try again.")