contact = {}

while True:
  print("1. Add a contact")
  print("2. Delete a contact")
  print("3. Update a contact")
  print("4. Search a contact")
  print("5. Display all contacts")
  print("6. Exit")
  choice = int(input("Enter your choice: "))
  if choice == 1:
    name = input("Enter the name: ")
    phone = input("Enter the phone number: ")
    email = input("Enter the email: ")
    contact[name] = phone = email
    print("Contact added successfully.")
  elif choice == 2:
    name = input("Enter the name: ")
    if name in contact:
      del contact[name]
      print("Contact deleted successfully.")
    else:
      print("Contact not found.")
  elif choice == 3:
    name = input("Enter the name: ")
    if name in contact:
      phone = input("Enter the new phone number: ")
      contact[name] = phone
      print("Contact updated successfully.")
    else:
      print("Contact not found.") 
  elif choice == 4:
    name = input("Enter the name: ")
    if name in contact:
      print("Phone number: ", contact[name])
    else:
      print("Contact not found.")
  elif choice == 5:
    if len(contact) == 0:
      print("No contacts found.")
    else:
      print("Name\tPhone number")
      for name, phone in contact.items():
        print(name, "\t", phone)
  elif choice == 6:
    break
  else:
    print("Invalid choice. Please try again.")
  
    
