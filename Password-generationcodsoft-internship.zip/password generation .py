import random
import string

s1 = string.ascii_lowercase
s2 = string.ascii_uppercase
s3 = string.digits
s4 = string.punctuation
characters_number = input("how many characters for the password?: ")

while True:
  try:
    characters_number = int(characters_number)
    if characters_number < 6:
      print("you need at least 6 characters")
      characters_number = input("please enter the number again: ")
    else:
      break
      
  except:
   print("please enter numbers only")
characters_number = input("how many characters for the password?: ")
random_password = ""
ascii_lowercase = list(string.ascii_lowercase)
ascii_uppercase = list(string.ascii_uppercase)
digits = list(string.digits)
punctuation = list(string.punctuation)


random.shuffle(ascii_lowercase)
random.shuffle(ascii_uppercase)
random.shuffle(digits)
random.shuffle(punctuation)


part1 = round(int(characters_number) * (30/100))
part2 = round(int(characters_number) * (20/100))

password = []

for i in range(part1):
  password.append(s1[i])
  password.append(s2[i])

for i in range(part2):
  password.append(s3[i])
  password.append(s4[i])

random.shuffle(password)

password = "".join(password[0:])

print(password)