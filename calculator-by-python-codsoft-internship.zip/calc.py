from tkinter import Button, Frame, Label, StringVar, Tk


class Calculator:
    def __init__(self, root):
        self.window = root
        self.window.title("Calculator Program")
        self.window.geometry("500x500")

        self.equation_text = ""
        self.equation_label = StringVar()

        label = Label(self.window, textvariable=self.equation_label, font=('consolas', 20), bg="white", width=24, height=2)
        label.pack()

        frame = Frame(self.window)
        frame.pack()

        self.create_buttons(frame)

    def create_buttons(self, frame):
        buttons = [
            ('1', 0, 0), ('2', 0, 1), ('3', 0, 2), ('+', 0, 3),
            ('4', 1, 0), ('5', 1, 1), ('6', 1, 2), ('-', 1, 3),
            ('7', 2, 0), ('8', 2, 1), ('9', 2, 2), ('*', 2, 3),
            ('0', 3, 0), ('/', 3, 1), ('=', 3, 2), ('C', 3, 3),
        ]

        for (text, row, column) in buttons:
            if text == "=":
                Button(frame, text=text, height=4, width=9, font=35, command=self.equals).grid(row=row, column=column)
            elif text == "C":
                Button(frame, text=text, height=4, width=9, font=35, command=self.clear).grid(row=row, column=column)
            else:
                Button(frame, text=text, height=4, width=9, font=35, command=lambda t=text: self.button_press(t)).grid(row=row, column=column)

    def button_press(self, num):
        self.equation_text += str(num)
        self.equation_label.set(self.equation_text)

    def equals(self):
        try:
            total = str(eval(self.equation_text))
            self.equation_label.set(total)
            self.equation_text = total
        except (ZeroDivisionError, SyntaxError):
            self.equation_label.set("Error")
            self.equation_text = ""

    def clear(self):
        self.equation_text = ""
        self.equation_label.set("")

if __name__ == "__main__":
    root = Tk()
    calculator = Calculator(root)
    root.mainloop()
